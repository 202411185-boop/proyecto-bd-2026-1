import React from 'react';
import { useCustomers } from './hooks/useCustomers';
import SearchBar from './components/SearchBar';
import CustomersTable from './components/CustomersTable';
import Pagination from './components/Pagination';
import { styles } from './styles';

export default function PaginaCliente() {
  const {
    clientes,
    loading,
    error,
    busqueda,
    pagina,
    totalPaginas,
    setPagina,
    handleBuscar,
    handleEliminar,
  } = useCustomers();

  const handleEditar = (customerid) => {
    // TODO: conectar a modal o ruta de edición cuando esté lista
    console.log('Editar cliente', customerid);
  };

  const handleAgregar = () => {
    // TODO: conectar a modal o ruta de creación cuando esté lista
    console.log('Agregar nuevo cliente');
  };

  return (
    <div style={styles.page}>
      <h1 style={styles.titulo}>Clientes</h1>

      <div style={styles.panel}>
        <div style={styles.barraSuperior}>
          <SearchBar
            value={busqueda}
            onChange={handleBuscar}
            placeholder="Busca por nombre"
            style={styles.buscador}
          />
          <button style={styles.botonAgregar} onClick={handleAgregar}>
            Agregar
          </button>
        </div>

        <CustomersTable
          clientes={clientes}
          loading={loading}
          error={error}
          onEditar={handleEditar}
          onEliminar={handleEliminar}
        />

        <Pagination
          pagina={pagina}
          totalPaginas={totalPaginas}
          onCambiarPagina={setPagina}
        />
      </div>
    </div>
  );
}
